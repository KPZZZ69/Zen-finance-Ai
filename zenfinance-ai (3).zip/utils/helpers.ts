export const CATEGORY_PALETTE = [
  '#ef4444', // Red 500
  '#f97316', // Orange 500
  '#f59e0b', // Amber 500
  '#84cc16', // Lime 500
  '#10b981', // Emerald 500
  '#14b8a6', // Teal 500
  '#06b6d4', // Cyan 500
  '#3b82f6', // Blue 500
  '#6366f1', // Indigo 500
  '#8b5cf6', // Violet 500
  '#a855f7', // Purple 500
  '#d946ef', // Fuchsia 500
  '#ec4899', // Pink 500
  '#f43f5e', // Rose 500
  '#64748b', // Slate 500
];

export const DEFAULT_CATEGORY_EMOJIS: Record<string, string> = {
  'Food': '🍔',
  'Travel': '✈️',
  'Mobile / Internet': '📱',
  'Entertainment': '🎬',
  'Shopping': '🛍️',
  'Miscellaneous': '✨',
  'Savings': '💰',
};

export const COMMON_EMOJIS = [
  '🍔', '🍕', '☕', '🍺', '🥦', // Food
  '✈️', '🚕', '⛽', '🚆', '🗺️', // Travel
  '📱', '💻', '📶', '🔌', '🏠', // Utilities
  '🎬', '🎮', '🎵', '🎟️', '📚', // Entertainment
  '🛍️', '👗', '👟', '🎁', '💄', // Shopping
  '💰', '🏦', '💎', '📉', '📈', // Finance
  '✨', '🏥', '💊', '🐶', '👶', // Misc
  '🎓', '🔧', '💪', '🎨', '📝'  // More
];


export const stringToColor = (str: string): string => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return CATEGORY_PALETTE[Math.abs(hash) % CATEGORY_PALETTE.length];
};

export const getColorForCategory = (category: string, colorMap?: Record<string, string>): string => {
  if (colorMap && colorMap[category]) {
    return colorMap[category];
  }
  return stringToColor(category);
};

export const getEmojiForCategory = (category: string, emojiMap?: Record<string, string>): string => {
  if (emojiMap && emojiMap[category]) {
    return emojiMap[category];
  }
  return DEFAULT_CATEGORY_EMOJIS[category] || '🏷️';
};
