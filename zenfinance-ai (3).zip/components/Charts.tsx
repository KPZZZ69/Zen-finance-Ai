import React, { useState, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Sector } from 'recharts';
import { Transaction } from '../types';
import { getColorForCategory, getEmojiForCategory } from '../utils/helpers';

interface ChartsProps {
  transactions: Transaction[];
  categoryColors: Record<string, string>;
  categoryEmojis: Record<string, string>;
}

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, value } = props;

  return (
    <g className="cursor-pointer outline-none focus:outline-none" tabIndex={-1}>
      {/* Label Text */}
      <text 
        x={cx} 
        y={cy} 
        dy={-15} 
        textAnchor="middle" 
        fill="#ffffff" 
        className="text-2xl md:text-3xl font-bold drop-shadow-lg animate-[fadeIn_0.2s_ease-out]"
      >
        {payload.name}
      </text>
      <text 
        x={cx} 
        y={cy} 
        dy={25} 
        textAnchor="middle" 
        fill="#94a3b8" 
        className="text-sm md:text-base font-medium tracking-wide animate-[fadeIn_0.2s_ease-out_0.05s]"
      >
        {`₹${value.toLocaleString('en-IN')}`}
      </text>
      
      {/* Outer Glow Ring (Subtle Halo) - Animates smoothly */}
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius - 4}
        outerRadius={outerRadius + 12}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        opacity={0.15}
        cornerRadius={12}
        className="transition-all duration-300 ease-out outline-none border-none focus:outline-none"
        stroke="none"
        strokeWidth={0}
      />
      
      {/* Main Expanded Slice with Elastic Pop */}
      {/* bezier(0.175, 0.885, 0.32, 1.275) creates a "spring" bounce effect */}
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 8}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        cornerRadius={8}
        className="transition-all duration-500 ease-[cubic-bezier(0.175,0.885,0.32,1.275)] outline-none border-none focus:outline-none"
        style={{ filter: `drop-shadow(0px 0px 8px ${fill}80)`, outline: 'none' }}
        stroke="none"
        strokeWidth={0}
      />
    </g>
  );
};

const Charts: React.FC<ChartsProps> = ({ transactions, categoryColors, categoryEmojis }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  // Memoize data calculation for 60fps performance
  const data = useMemo(() => {
    const expenseTransactions = transactions.filter(t => t.type === 'expense');
    
    if (expenseTransactions.length === 0) return [];

    const groupedData: Record<string, number> = {};
    expenseTransactions.forEach(t => {
      if (!groupedData[t.category]) {
        groupedData[t.category] = 0;
      }
      groupedData[t.category] += t.amount;
    });

    return Object.entries(groupedData)
      .map(([name, value]) => ({ name, value }))
      .filter(item => item.value > 0)
      .sort((a, b) => b.value - a.value);
  }, [transactions]);

  const totalExpense = useMemo(() => 
    data.reduce((acc, item) => acc + item.value, 0)
  , [data]);

  // Memoize legend renderer
  const renderLegend = (props: any) => {
    const { payload } = props;
    return (
      <div className="grid grid-cols-2 gap-3 mt-6 px-2 max-h-40 overflow-y-auto no-scrollbar">
        {payload.map((entry: any, index: number) => {
            const categoryName = entry.value;
            const emoji = getEmojiForCategory(categoryName, categoryEmojis);
            const color = getColorForCategory(categoryName, categoryColors);
            const item = data.find(d => d.name === categoryName);
            const percent = item ? ((item.value / totalExpense) * 100).toFixed(0) : 0;
            const isActive = index === activeIndex;

            return (
              <div 
                key={`item-${index}`} 
                className={`
                  flex items-center gap-3 p-2.5 rounded-xl transition-all duration-300 cursor-pointer border outline-none
                  ${isActive 
                    ? 'bg-white/10 border-white/10 translate-x-1 shadow-lg' 
                    : 'bg-transparent border-transparent hover:bg-white/5 opacity-70 hover:opacity-100'}
                `}
                onClick={() => setActiveIndex(index)}
              >
                 <div 
                    className={`
                      w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-sm transition-transform duration-300
                      ${isActive ? 'scale-110' : 'scale-100'}
                    `}
                    style={{ 
                      backgroundColor: `${color}20`,
                      border: `1px solid ${color}40`,
                      boxShadow: isActive ? `0 0 15px ${color}50` : 'none'
                    }}
                 >
                    {emoji}
                 </div>
                 <div className="flex flex-col min-w-0">
                    <span className={`text-xs font-bold truncate transition-colors ${isActive ? 'text-white' : 'text-slate-400'}`}>
                        {categoryName}
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1.5">
                        <span className={`${isActive ? 'text-white' : 'text-slate-500'}`}>{percent}%</span>
                        <span className="w-0.5 h-2.5 bg-white/10 rounded-full"></span>
                        <span style={{ color: isActive ? color : '#64748b' }}>₹{item?.value.toLocaleString('en-IN')}</span>
                    </span>
                 </div>
              </div>
            )
        })}
      </div>
    );
  };

  if (data.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-80 bg-slate-900/20 rounded-[2.5rem] border border-white/5 border-dashed text-slate-500 gap-4">
        <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center animate-pulse">
            <span className="text-3xl opacity-50 grayscale">📉</span>
        </div>
        <span className="text-sm font-medium tracking-wide">No expenses to visualize</span>
      </div>
    );
  }

  return (
    // [&_*]:outline-none removes focus outline from all children (paths, groups)
    <div className="h-[30rem] w-full -ml-2 flex flex-col [&_*]:outline-none [&_*:focus]:outline-none select-none">
      <div className="flex-1 w-full min-h-0 relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <defs>
              <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur in="SourceAlpha" stdDeviation="3" />
                <feOffset dx="0" dy="2" result="offsetblur" />
                <feComponentTransfer>
                  <feFuncA type="linear" slope="0.5" />
                </feComponentTransfer>
                <feMerge>
                  <feMergeNode />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <Pie
              activeIndex={activeIndex}
              activeShape={renderActiveShape}
              data={data}
              cx="50%"
              cy="42%" 
              innerRadius={70}
              outerRadius={95}
              paddingAngle={2}
              dataKey="value"
              stroke="none" // Removes the white border line
              animationBegin={0}
              animationDuration={1000}
              animationEasing="ease-out"
              onMouseEnter={onPieEnter}
              onClick={onPieEnter}
              cornerRadius={6}
            >
              {data.map((entry, index) => {
                const color = getColorForCategory(entry.name, categoryColors);
                const isActive = index === activeIndex;
                
                return (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={color} 
                    className="stroke-none outline-none focus:outline-none transition-opacity duration-300 ease-out border-none"
                    fillOpacity={activeIndex === index || activeIndex === undefined ? 1 : 0.4} // Spotlight effect
                    style={{ 
                      filter: isActive ? `drop-shadow(0px 0px 8px ${color}60)` : 'none',
                      transform: isActive ? 'scale(1.02)' : 'scale(1)',
                      transformOrigin: 'center center',
                      outline: 'none',
                    }}
                  />
                );
              })}
            </Pie>
            <Legend content={renderLegend} verticalAlign="bottom" />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Charts;