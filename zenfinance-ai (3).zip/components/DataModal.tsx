import React, { useRef } from 'react';
import { X, Download, Upload, Save, AlertTriangle } from 'lucide-react';
import { AppState } from '../types';

interface DataModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onImport: (data: AppState) => void;
}

const DataModal: React.FC<DataModalProps> = ({ isOpen, onClose, state, onImport }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleExport = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `zenfinance_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        
        // Basic schema validation
        if (
             json.categories && Array.isArray(json.categories) &&
             (json.transactions && Array.isArray(json.transactions) || json.transactions === undefined)
           ) {
          
          if (confirm("⚠️ Warning: Importing a backup will OVERWRITE all current data. This action cannot be undone. Do you want to proceed?")) {
             onImport(json);
             onClose();
             alert("Data restored successfully!");
          }
        } else {
          alert("Error: The selected file does not appear to be a valid ZenFinance backup.");
        }
      } catch (err) {
        alert("Error: Failed to parse the backup file.");
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset input to allow re-selecting same file
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      />

      <div className="
        relative w-full max-w-sm
        bg-slate-900/90 backdrop-blur-2xl
        border border-white/10
        rounded-3xl shadow-2xl
        p-6
        animate-[fadeIn_0.2s_ease-out]
      ">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Save className="text-cyan-400" />
            Data Management
          </h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-4">
            
            <p className="text-sm text-slate-400 mb-4">
                Your data is automatically saved to this device. Use these options to back up your data or move it to another device.
            </p>

            {/* Export Button */}
            <button
                onClick={handleExport}
                className="w-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium p-4 rounded-2xl transition-all flex items-center justify-between group"
            >
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-cyan-500/20 rounded-lg text-cyan-400 group-hover:scale-110 transition-transform">
                        <Download size={20} />
                    </div>
                    <div className="text-left">
                        <div className="font-bold">Backup Data</div>
                        <div className="text-xs text-slate-500">Save to a .json file</div>
                    </div>
                </div>
            </button>

            {/* Import Button */}
            <button
                onClick={handleImportClick}
                className="w-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium p-4 rounded-2xl transition-all flex items-center justify-between group"
            >
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-500/20 rounded-lg text-emerald-400 group-hover:scale-110 transition-transform">
                        <Upload size={20} />
                    </div>
                    <div className="text-left">
                        <div className="font-bold">Restore Backup</div>
                        <div className="text-xs text-slate-500">Load from a .json file</div>
                    </div>
                </div>
            </button>
            <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept=".json"
            />

             <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl flex gap-2 items-start text-xs text-yellow-200/80">
                <AlertTriangle size={14} className="mt-0.5 shrink-0" />
                <span>Auto-save is active. Data persists after app restart automatically.</span>
             </div>

        </div>
      </div>
    </div>
  );
};

export default DataModal;