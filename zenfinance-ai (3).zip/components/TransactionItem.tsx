import React from 'react';
import { Repeat } from 'lucide-react';
import { Transaction } from '../types';

interface TransactionItemProps {
  transaction: Transaction;
  categoryColor: string;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ transaction, categoryColor }) => {
  const isIncome = transaction.type === 'income';
  const date = new Date(transaction.date);
  const timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const isRecurring = transaction.recurrence && transaction.recurrence !== 'none';

  return (
    <div className="
      group relative 
      flex items-center justify-between 
      p-4 mb-3 
      bg-white/5 
      backdrop-blur-md 
      rounded-2xl 
      border border-white/5 
      transition-all duration-200 ease-out
      active:scale-[0.98] active:bg-white/10
    ">
      {/* Category colored glow bar on left */}
      <div 
        className="absolute left-0 top-3 bottom-3 w-1 rounded-r-full opacity-60 transition-all group-active:opacity-100 group-active:w-1.5"
        style={{ backgroundColor: categoryColor, boxShadow: `0 0 10px ${categoryColor}` }}
      />

      <div className="flex items-center gap-4 pl-3">
        <div 
          className="
            relative
            w-12 h-12 flex items-center justify-center 
            rounded-2xl text-2xl 
            bg-black/20 border border-white/5
            group-active:scale-105 transition-transform duration-200
          "
        >
          {/* Glow behind emoji */}
          <div 
            className="absolute inset-0 rounded-2xl opacity-0 group-active:opacity-20 transition-opacity duration-300 blur-md"
            style={{ backgroundColor: categoryColor }}
          />
          <span className="relative z-10 drop-shadow-md">{transaction.emoji || '✨'}</span>
        </div>
        
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-100 text-lg tracking-wide group-active:text-white transition-colors">
              {transaction.description || transaction.category}
            </span>
            {isRecurring && (
              <Repeat size={12} className="text-primary opacity-70" />
            )}
          </div>
          <div className="flex items-center gap-2">
            <span 
                className="text-[10px] px-2 py-0.5 rounded-full font-bold text-white/90 shadow-sm"
                style={{ backgroundColor: `${categoryColor}aa`, backdropFilter: 'blur(4px)' }}
            >
                {transaction.category}
            </span>
            <span className="text-xs text-slate-500 font-medium group-active:text-slate-400">
                {timeString}
            </span>
          </div>
        </div>
      </div>

      <div className={`
        text-lg font-bold tracking-tight
        ${isIncome ? 'text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]' : 'text-slate-200 group-active:text-white'}
      `}>
        {isIncome ? '+' : '-'}₹{transaction.amount.toLocaleString('en-IN')}
      </div>
    </div>
  );
};

export default TransactionItem;