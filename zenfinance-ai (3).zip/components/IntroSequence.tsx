import React, { useEffect, useRef, useState } from 'react';
import { Power } from 'lucide-react';

interface IntroSequenceProps {
  type: 'cinematic' | 'micro';
  onComplete: () => void;
}

const IntroSequence: React.FC<IntroSequenceProps> = ({ type, onComplete }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const animationRef = useRef<number>(0);
  
  // Visual State
  const [showGate, setShowGate] = useState(false);
  const [phase, setPhase] = useState<'idle' | 'void' | 'chaos' | 'order' | 'reveal' | 'wake' | 'pulse' | 'flow'>('idle');
  const [textLine1, setTextLine1] = useState('');
  const [textLine2, setTextLine2] = useState('');
  const [opacity, setOpacity] = useState(1);

  // Audio Engine Initialization
  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      audioCtxRef.current = new AudioContext();
    }
    return audioCtxRef.current;
  };

  // Attempt to unlock audio on any interaction
  const tryUnlockAudio = () => {
    const ctx = audioCtxRef.current;
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  };

  // Complex Sound Synthesis Layer
  const playSound = (layer: 'drone' | 'heartbeat' | 'glitch_layer' | 'riser' | 'sweep' | 'chord_hit' | 'ambient_pad' | 'inhale' | 'ai_chime' | 'bass_pulse' | 'click') => {
    const ctx = initAudio();
    // Try resume, but don't await (fire and forget)
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    
    const t = ctx.currentTime;

    switch (layer) {
      // --- CINEMATIC INTRO SOUNDS ---
      case 'drone': {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(35, t); 
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(200, t);
        filter.frequency.linearRampToValueAtTime(100, t + 7); 

        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.4, t + 1);
        gain.gain.linearRampToValueAtTime(0, t + 7);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 7.1);
        break;
      }
      case 'heartbeat': {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(45, t);
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.8, t + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.6);
        break;
      }
      case 'glitch_layer': {
        const coinOsc = ctx.createOscillator();
        const coinGain = ctx.createGain();
        coinOsc.type = 'sine';
        coinOsc.frequency.setValueAtTime(1200 + Math.random() * 1000, t);
        coinGain.gain.setValueAtTime(0.05, t);
        coinGain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
        coinOsc.connect(coinGain);
        coinGain.connect(ctx.destination);
        coinOsc.start(t);
        coinOsc.stop(t + 0.5);

        const tickOsc = ctx.createOscillator();
        const tickGain = ctx.createGain();
        tickOsc.type = 'square';
        tickOsc.frequency.setValueAtTime(2000 + Math.random() * 500, t);
        tickGain.gain.setValueAtTime(0.02, t);
        tickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.02);
        tickOsc.connect(tickGain);
        tickGain.connect(ctx.destination);
        tickOsc.start(t);
        tickOsc.stop(t + 0.03);
        break;
      }
      case 'riser': {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(100, t);
        osc.frequency.exponentialRampToValueAtTime(800, t + 2);
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.05, t + 1.8);
        gain.gain.setValueAtTime(0, t + 2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 2);
        break;
      }
      case 'sweep': {
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.Q.value = 5;
        filter.frequency.setValueAtTime(200, t);
        filter.frequency.exponentialRampToValueAtTime(5000, t + 1);

        const bufferSize = ctx.sampleRate;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.2, t + 0.5);
        gain.gain.linearRampToValueAtTime(0, t + 1);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        noise.start(t);
        break;
      }
      case 'chord_hit': {
        const freqs = [261.63, 349.23, 392.00, 523.25];
        freqs.forEach(f => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.value = f;
          gain.gain.setValueAtTime(0, t);
          gain.gain.linearRampToValueAtTime(0.08, t + 0.05);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 3);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(t);
          osc.stop(t + 3.1);
        });

        const bellOsc = ctx.createOscillator();
        const bellGain = ctx.createGain();
        bellOsc.frequency.setValueAtTime(1567.98, t);
        bellGain.gain.setValueAtTime(0, t);
        bellGain.gain.linearRampToValueAtTime(0.1, t + 0.01);
        bellGain.gain.exponentialRampToValueAtTime(0.001, t + 1.5);
        bellOsc.connect(bellGain);
        bellGain.connect(ctx.destination);
        bellOsc.start(t);
        bellOsc.stop(t + 1.5);

        const bassOsc = ctx.createOscillator();
        const bassGain = ctx.createGain();
        bassOsc.type = 'triangle';
        bassOsc.frequency.setValueAtTime(60, t);
        bassOsc.frequency.exponentialRampToValueAtTime(30, t + 0.5);
        bassGain.gain.setValueAtTime(0.4, t);
        bassGain.gain.exponentialRampToValueAtTime(0.001, t + 1);
        bassOsc.connect(bassGain);
        bassGain.connect(ctx.destination);
        bassOsc.start(t);
        bassOsc.stop(t + 1.1);
        break;
      }

      // --- REPEATING INTRO SOUNDS (Smoother Envelopes) ---
      case 'ambient_pad': {
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc1.type = 'triangle';
        osc1.frequency.setValueAtTime(146.83, t); // D3
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(220.00, t); // A3

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, t);

        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.15, t + 1.5); 
        gain.gain.linearRampToValueAtTime(0, t + 5.0); 

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(t);
        osc2.start(t);
        osc1.stop(t + 5.0);
        osc2.stop(t + 5.0);
        break;
      }
      case 'inhale': {
        const bufferSize = ctx.sampleRate * 2;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * 0.5;

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.Q.value = 1;
        filter.frequency.setValueAtTime(200, t);
        filter.frequency.exponentialRampToValueAtTime(800, t + 1.5);

        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.05, t + 1.0);
        gain.gain.linearRampToValueAtTime(0, t + 1.5);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        noise.start(t);
        break;
      }
      case 'ai_chime': {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1174.66, t); 
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.08, t + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 2.0);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 2.0);
        break;
      }
      case 'bass_pulse': {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(60, t);
        osc.frequency.exponentialRampToValueAtTime(40, t + 0.5);
        
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.2, t + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 1.5);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 1.5);
        break;
      }
      case 'click': {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(2000, t);
        
        const filter = ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 1000;

        gain.gain.setValueAtTime(0.02, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.05);
        break;
      }
    }
  };

  const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  useEffect(() => {
    // Global listener to unlock audio on any user tap during intro
    window.addEventListener('click', tryUnlockAudio, { once: true });
    window.addEventListener('touchstart', tryUnlockAudio, { once: true });

    // ----------------------------------------------------
    // REPEATING INTRO (5.0s Duration)
    // ----------------------------------------------------
    if (type === 'micro') {
      const runRepeating = async () => {
        const ctx = initAudio();
        // Try to unlock immediately for repeat users
        ctx.resume().catch(() => {});

        // SCENE 1: SOFT WAKE (0.0s - 1.5s)
        setPhase('wake');
        playSound('ambient_pad');
        playSound('inhale');

        await wait(1500);

        // SCENE 2: CONFIDENCE PULSE (1.5s - 3.5s)
        setPhase('pulse');
        playSound('ai_chime');
        playSound('bass_pulse');

        await wait(2000);

        // SCENE 3: FLOW INTO APP (3.5s - 5.0s)
        setPhase('flow');
        playSound('click');

        await wait(1500);

        setOpacity(0);
        onComplete();
      };
      runRepeating();
      return () => {
        window.removeEventListener('click', tryUnlockAudio);
        window.removeEventListener('touchstart', tryUnlockAudio);
      };
    }

    // ----------------------------------------------------
    // CINEMATIC INTRO GATE
    // ----------------------------------------------------
    setShowGate(true);
    return () => {
        window.removeEventListener('click', tryUnlockAudio);
        window.removeEventListener('touchstart', tryUnlockAudio);
    };
  }, [type]);

  const handleStartCinematic = async () => {
    setShowGate(false);
    
    const ctx = initAudio();
    await ctx.resume();

    // SCENE 1: THE VOID
    setPhase('void');
    setTextLine1('Money is chaos...');
    playSound('drone');
    
    await wait(1200);
    playSound('heartbeat');
    await wait(600); 

    // SCENE 2: MONEY CHAOS
    setPhase('chaos');
    setTextLine1('');
    playSound('riser');
    
    const chaosInterval = setInterval(() => {
      if (Math.random() > 0.5) playSound('glitch_layer');
    }, 150);

    await wait(2000);
    clearInterval(chaosInterval);

    // SCENE 3: AI CONTROL
    setPhase('order');
    playSound('sweep');
    setTextLine2('...until intelligence brings balance.');
    await wait(1400);

    // SCENE 4: ZENFINANCE REVEAL
    setPhase('reveal');
    setTextLine2('');
    playSound('chord_hit');
    await wait(1800);

    setOpacity(0);
    await wait(1000);
    onComplete();
  };

  // ----------------------------------------------------
  // OPTIMIZED VISUAL ENGINE (CANVAS)
  // ----------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false }); // Optimization
    if (!ctx) return;

    let particles: Particle[] = [];
    const symbols = ['₹', '$', '%', '+', '÷'];
    let startTime = Date.now();

    class Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      text: string;
      alpha: number;
      size: number;

      constructor(w: number, h: number) {
        this.x = Math.random() * w;
        this.y = Math.random() * h;
        this.vx = (Math.random() - 0.5) * 4; // Reduced speed for smoothness
        this.vy = (Math.random() - 0.5) * 4;
        this.text = symbols[Math.floor(Math.random() * symbols.length)];
        this.alpha = 0;
        this.size = Math.random() * 12 + 10;
      }

      update(phase: string, w: number, h: number, time: number) {
        if (phase === 'chaos') {
          this.alpha = Math.min(this.alpha + 0.05, 0.6);
          this.x += this.vx;
          this.y += this.vy;
          if (this.x < 0 || this.x > w) this.vx *= -1;
          if (this.y < 0 || this.y > h) this.vy *= -1;
        } 
        else if (phase === 'order') {
          // Simplified flocking behavior
          const targetY = h / 2 + Math.sin(this.x * 0.02 + time * 0.005) * 40;
          this.y += (targetY - this.y) * 0.1;
          this.x += 2; 
          if(this.x > w) this.x = 0;
          this.alpha = Math.max(this.alpha - 0.01, 0.3);
        }
        else if (phase === 'reveal') {
           this.alpha -= 0.05;
        }
      }

      draw(ctx: CanvasRenderingContext2D) {
        if (this.alpha <= 0.01) return;
        ctx.fillStyle = '#22d3ee'; // Cyan
        ctx.globalAlpha = this.alpha;
        ctx.font = `${this.size}px monospace`;
        ctx.fillText(this.text, this.x, this.y);
      }
    }

    const resize = () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    // Reduce particle count significantly for mobile performance (25 particles)
    particles = Array.from({ length: 25 }, () => new Particle(canvas.width, canvas.height));
    let voidGlow = 0;

    const render = () => {
      const now = Date.now();
      const time = now - startTime;
      
      // Clear with solid color (faster than clearRect with transparency)
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#020617';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // --- CINEMATIC VISUALS ---
      if (phase === 'void') {
         voidGlow += 0.02;
         const opacity = Math.min(voidGlow, 1) * 0.5 + Math.sin(time * 0.002) * 0.2;
         
         ctx.globalAlpha = opacity;
         ctx.fillStyle = '#ffffff';
         ctx.beginPath();
         ctx.arc(canvas.width / 2, canvas.height / 2, 4, 0, Math.PI * 2);
         ctx.fill();
         // Simulated glow with simple larger circle
         ctx.globalAlpha = opacity * 0.3;
         ctx.beginPath();
         ctx.arc(canvas.width / 2, canvas.height / 2, 20, 0, Math.PI * 2);
         ctx.fill();
      }
      else if (phase === 'chaos' || phase === 'order' || phase === 'reveal') {
         particles.forEach(p => {
           p.update(phase, canvas.width, canvas.height, time);
           p.draw(ctx);
         });
         
         if (phase === 'order') {
            ctx.globalAlpha = 0.5;
            ctx.strokeStyle = '#06b6d4';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(0, canvas.height / 2);
            for(let x = 0; x < canvas.width; x+=20) {
               ctx.lineTo(x, canvas.height / 2 + Math.sin(x * 0.01 + time * 0.01) * 20);
            }
            ctx.stroke();
         }
      }

      // --- REPEATING INTRO VISUALS ---
      // Replaced expensive canvas gradients/blurs with simple drawing
      if (phase === 'wake' || phase === 'pulse' || phase === 'flow') {
        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        
        // Simple background tint instead of gradient
        ctx.globalAlpha = 0.05;
        if(phase === 'wake') ctx.globalAlpha = Math.min((time/1500) * 0.05, 0.05);
        ctx.fillStyle = '#06b6d4';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Neon Ring (Simple Stroke)
        if (phase === 'pulse' || phase === 'flow') {
          const ringTime = (time % 2000) / 2000; 
          const ringRadius = 50 + ringTime * 200;
          const ringAlpha = (1 - ringTime) * 0.4;
          
          ctx.beginPath();
          ctx.arc(cx, cy, ringRadius, 0, Math.PI*2);
          ctx.strokeStyle = '#22d3ee';
          ctx.lineWidth = 1;
          ctx.globalAlpha = ringAlpha;
          ctx.stroke();
          
          // Scan line (Simple rect)
          if (phase === 'pulse') {
             const scanY = (time % 1500) / 1500 * canvas.height;
             ctx.fillStyle = '#22d3ee';
             ctx.globalAlpha = 0.03;
             ctx.fillRect(0, scanY, canvas.width, 40);
          }
        }
      }

      animationRef.current = requestAnimationFrame(render);
    };

    render();
    return () => {
        cancelAnimationFrame(animationRef.current);
        window.removeEventListener('resize', resize);
    };
  }, [phase]);


  // ----------------------------------------------------
  // RENDER UI
  // ----------------------------------------------------
  const isRepeating = type === 'micro';
  
  // Use hardware accelerated CSS transforms for logo
  const logoStyle = (() => {
      if (!isRepeating) return {}; // Cinematic uses separate flow
      
      switch(phase) {
          case 'wake': return { opacity: 1, transform: 'scale(1)', transition: 'opacity 1.5s ease-out' };
          case 'pulse': return { opacity: 1, transform: 'scale(1.1)', transition: 'transform 2s ease-in-out' };
          case 'flow': return { opacity: 0, transform: 'scale(0.9)', transition: 'all 1s ease-in' };
          default: return { opacity: 0 };
      }
  })();

  return (
    <div 
      className="fixed inset-0 z-[100] bg-[#020617] flex flex-col items-center justify-center overflow-hidden transition-opacity duration-1000 ease-in-out will-change-opacity"
      style={{ opacity }}
    >
      {/* Cinematic Gate Button */}
      {showGate && type === 'cinematic' && (
        <div className="absolute inset-0 z-[110] flex flex-col items-center justify-center bg-[#020617] animate-[fadeIn_0.5s_ease-out]">
          <button 
            onClick={handleStartCinematic}
            className="group relative flex flex-col items-center justify-center outline-none active:scale-95 transition-transform"
          >
            <div className="absolute inset-0 bg-cyan-500/10 rounded-full blur-xl animate-pulse"></div>
            <div className="relative w-20 h-20 rounded-full border border-cyan-500/30 flex items-center justify-center group-hover:scale-105 transition-transform duration-500 bg-[#020617]">
               <Power size={24} className="text-cyan-400 group-hover:text-white transition-colors" />
            </div>
            <span className="mt-6 text-xs text-cyan-500/60 uppercase tracking-[0.4em] font-light group-hover:text-cyan-400 transition-colors">
              Initialize
            </span>
          </button>
        </div>
      )}

      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center justify-center text-center w-full max-w-lg px-6">
        
        {/* Cinematic Text */}
        {phase === 'void' && (
           <p className="text-slate-300 font-light text-xl tracking-[0.3em] animate-[fadeIn_2s_ease-out] opacity-80">
             {textLine1}
           </p>
        )}
        {phase === 'order' && (
           <p className="text-cyan-100/90 font-light text-xl md:text-2xl tracking-[0.15em] animate-[fadeIn_0.5s_ease-out]">
             {textLine2}
           </p>
        )}

        {/* Logo Container */}
        {(phase === 'reveal' || isRepeating) && (
          <div 
            className={`flex flex-col items-center ${!isRepeating ? 'animate-[fadeIn_0.8s_ease-out]' : ''}`}
            style={isRepeating ? logoStyle : {}}
          >
             <div className="relative w-32 h-32 mb-6">
                <svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-white drop-shadow-lg">
                  <path 
                    d="M23 6L13.5 15.5L8.5 10.5L1 18" 
                    className={!isRepeating ? "animate-[drawPath_1.5s_cubic-bezier(0.2,0,0,1)_forwards]" : ""}
                    strokeDasharray="30"
                    strokeDashoffset={!isRepeating ? "30" : "0"}
                  />
                  <path 
                    d="M17 6H23V12" 
                    className={!isRepeating ? "animate-[drawPath_1.5s_cubic-bezier(0.2,0,0,1)_0.2s_forwards]" : ""}
                    strokeDasharray="20"
                    strokeDashoffset={!isRepeating ? "20" : "0"}
                  />
                </svg>
             </div>
             
             <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-blue-300 tracking-tight mb-4 drop-shadow-xl">
               ZenFinance
             </h1>
             
             {type === 'cinematic' && (
                <div className="flex flex-col items-center gap-4 animate-[slideUp_1s_ease-out]">
                    <div className="h-px w-12 bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>
                    <p className="text-cyan-400/80 text-xs font-mono tracking-widest">
                       "Just type. Zen handles the rest."
                    </p>
                </div>
             )}
          </div>
        )}
      </div>

      <style>{`
        @keyframes drawPath {
          to { stroke-dashoffset: 0; }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default IntroSequence;