import React, { useState } from 'react';
import { X, Plus, Trash2, Edit2, Check, Palette, Smile } from 'lucide-react';
import { CATEGORY_PALETTE, COMMON_EMOJIS, getColorForCategory, getEmojiForCategory } from '../utils/helpers';

interface CategoryManagerProps {
  isOpen: boolean;
  onClose: () => void;
  categories: string[];
  categoryColors: Record<string, string>;
  categoryEmojis: Record<string, string>;
  onAdd: (name: string, color: string, emoji: string) => void;
  onEdit: (oldName: string, newName: string, newColor: string, newEmoji: string) => void;
  onDelete: (name: string) => void;
}

const CategoryManager: React.FC<CategoryManagerProps> = ({
  isOpen,
  onClose,
  categories,
  categoryColors,
  categoryEmojis,
  onAdd,
  onEdit,
  onDelete,
}) => {
  const [newCategory, setNewCategory] = useState('');
  const [selectedColor, setSelectedColor] = useState(CATEGORY_PALETTE[0]);
  const [selectedEmoji, setSelectedEmoji] = useState(COMMON_EMOJIS[0]);
  
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState('');
  const [editEmoji, setEditEmoji] = useState('');
  const [showPicker, setShowPicker] = useState<{id: string, type: 'color' | 'emoji'} | null>(null);

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCategory.trim()) {
      onAdd(newCategory.trim(), selectedColor, selectedEmoji);
      setNewCategory('');
      setSelectedColor(CATEGORY_PALETTE[Math.floor(Math.random() * CATEGORY_PALETTE.length)]);
      setSelectedEmoji(COMMON_EMOJIS[Math.floor(Math.random() * COMMON_EMOJIS.length)]);
      setShowPicker(null);
    }
  };

  const startEdit = (cat: string) => {
    setEditingCategory(cat);
    setEditName(cat);
    setEditColor(getColorForCategory(cat, categoryColors));
    setEditEmoji(getEmojiForCategory(cat, categoryEmojis));
    setShowPicker(null);
  };

  const saveEdit = () => {
    if (editingCategory && editName.trim()) {
      onEdit(editingCategory, editName.trim(), editColor, editEmoji);
    }
    setEditingCategory(null);
    setEditName('');
    setEditColor('');
    setEditEmoji('');
    setShowPicker(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop with strong blur */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      />

      <div className="
        relative w-full max-w-md 
        bg-slate-900/80 backdrop-blur-2xl
        border border-white/10
        rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.5)]
        overflow-hidden flex flex-col max-h-[80vh]
        animate-[fadeIn_0.2s_ease-out]
      ">
        <div className="p-5 border-b border-white/5 flex justify-between items-center bg-white/5">
          <h3 className="text-lg font-bold text-white tracking-wide">Manage Categories</h3>
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2 no-scrollbar">
          {categories.map((cat) => {
            const isEditing = editingCategory === cat;
            const displayColor = isEditing ? editColor : getColorForCategory(cat, categoryColors);
            const displayEmoji = isEditing ? editEmoji : getEmojiForCategory(cat, categoryEmojis);

            return (
              <div 
                key={cat} 
                className="group flex flex-col p-3 rounded-2xl border border-transparent hover:border-white/5 hover:bg-white/5 transition-all"
              >
                <div className="flex items-center justify-between w-full">
                  {isEditing ? (
                    <div className="flex items-center gap-2 w-full animate-[fadeIn_0.1s_ease-out]">
                       {/* Emoji Picker Button */}
                       <button
                        type="button"
                        onClick={() => setShowPicker(showPicker?.id === cat && showPicker.type === 'emoji' ? null : {id: cat, type: 'emoji'})}
                        className="w-8 h-8 rounded-full bg-black/30 border border-white/10 flex items-center justify-center text-lg hover:bg-white/10"
                      >
                         {editEmoji}
                      </button>

                       {/* Color Picker Button */}
                       <button
                        type="button"
                        onClick={() => setShowPicker(showPicker?.id === cat && showPicker.type === 'color' ? null : {id: cat, type: 'color'})}
                        className="w-8 h-8 rounded-full border border-white/20 shadow-inner flex items-center justify-center"
                        style={{ backgroundColor: editColor }}
                      >
                         <Palette size={14} className="text-black/50" />
                      </button>

                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="flex-1 bg-black/30 border border-primary/50 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary"
                        autoFocus
                      />
                      <button onClick={saveEdit} className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl hover:bg-emerald-500/30">
                        <Check size={16} />
                      </button>
                      <button onClick={() => setEditingCategory(null)} className="p-2 bg-white/10 text-slate-400 rounded-xl hover:bg-white/20">
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-4">
                        <div 
                          className="w-10 h-10 flex items-center justify-center rounded-xl bg-black/20 text-xl border border-white/5 shadow-sm"
                          style={{ borderColor: `${displayColor}40` }}
                        >
                            <span className="animate-float">{displayEmoji}</span>
                        </div>
                        <span className="text-slate-200 font-medium tracking-wide flex items-center gap-2">
                            {cat}
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: displayColor }}></div>
                        </span>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => startEdit(cat)}
                          className="p-2 text-slate-400 hover:text-primary hover:bg-primary/10 rounded-xl transition-colors"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button 
                          onClick={() => onDelete(cat)}
                          className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </>
                  )}
                </div>

                {/* Edit Pickers */}
                {isEditing && showPicker?.id === cat && (
                  <div className="mt-3 p-3 bg-black/20 rounded-xl animate-[fadeIn_0.2s_ease-out]">
                      {showPicker.type === 'color' ? (
                          <div className="grid grid-cols-8 gap-2">
                             {CATEGORY_PALETTE.map(c => (
                                <button
                                    key={c}
                                    onClick={() => setEditColor(c)}
                                    className={`w-6 h-6 rounded-full transition-transform hover:scale-125 ${editColor === c ? 'ring-2 ring-white scale-110' : ''}`}
                                    style={{ backgroundColor: c }}
                                />
                                ))}
                          </div>
                      ) : (
                          <div className="grid grid-cols-8 gap-2">
                            {COMMON_EMOJIS.map(e => (
                                <button
                                    key={e}
                                    onClick={() => setEditEmoji(e)}
                                    className={`w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-xl ${editEmoji === e ? 'bg-white/20' : ''}`}
                                >
                                    {e}
                                </button>
                            ))}
                          </div>
                      )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Add New Category Section */}
        <div className="p-5 border-t border-white/5 bg-white/5 backdrop-blur-xl">
          <form onSubmit={handleAdd} className="flex flex-col gap-3">
            <div className="flex gap-3">
              {/* Emoji Picker Trigger */}
              <button
                type="button"
                onClick={() => setShowPicker(showPicker?.id === 'new' && showPicker.type === 'emoji' ? null : {id: 'new', type: 'emoji'})}
                className="w-12 h-12 rounded-2xl border border-white/10 flex items-center justify-center shrink-0 transition-all hover:border-white/30 bg-black/20 text-2xl"
              >
                 {selectedEmoji}
              </button>

              {/* Color Picker Trigger */}
              <button
                type="button"
                onClick={() => setShowPicker(showPicker?.id === 'new' && showPicker.type === 'color' ? null : {id: 'new', type: 'color'})}
                className="w-12 h-12 rounded-2xl border border-white/10 flex items-center justify-center shrink-0 transition-all hover:border-white/30"
                style={{ backgroundColor: selectedColor }}
              >
                 <Palette size={20} className="text-white drop-shadow-md" />
              </button>
              
              <input
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="New Category..."
                className="flex-1 bg-black/20 border border-white/10 rounded-2xl px-5 py-3 text-sm text-white focus:outline-none focus:border-primary/50 focus:bg-black/40 transition-all placeholder:text-slate-500"
              />
              <button 
                type="submit" 
                disabled={!newCategory.trim()}
                className="bg-primary hover:bg-blue-600 text-white p-3 rounded-2xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:scale-105 active:scale-95"
              >
                <Plus size={20} />
              </button>
            </div>
            
            {/* New Category Pickers */}
            {showPicker?.id === 'new' && (
              <div className="p-3 bg-black/20 rounded-xl animate-[fadeIn_0.2s_ease-out]">
                   {showPicker.type === 'color' ? (
                        <div className="grid grid-cols-8 gap-3">
                            {CATEGORY_PALETTE.map(c => (
                            <button
                                key={c}
                                type="button"
                                onClick={() => setSelectedColor(c)}
                                className={`w-8 h-8 rounded-full transition-transform hover:scale-125 ${selectedColor === c ? 'ring-2 ring-white scale-110' : ''}`}
                                style={{ backgroundColor: c }}
                            />
                            ))}
                        </div>
                   ) : (
                       <div className="grid grid-cols-8 gap-3">
                           {COMMON_EMOJIS.map(e => (
                               <button
                                   key={e}
                                   type="button"
                                   onClick={() => setSelectedEmoji(e)}
                                   className={`w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-xl ${selectedEmoji === e ? 'bg-white/20' : ''}`}
                               >
                                   {e}
                               </button>
                           ))}
                       </div>
                   )}
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default CategoryManager;