import React from 'react';
import { X, ShieldCheck, AlertTriangle, Lightbulb, Zap } from 'lucide-react';
import { FinancialAdvice } from '../types';

interface AdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  advice: FinancialAdvice | null;
  isLoading: boolean;
}

const AdvisorModal: React.FC<AdvisorModalProps> = ({
  isOpen,
  onClose,
  advice,
  isLoading,
}) => {
  if (!isOpen) return null;

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-400';
    if (score >= 50) return 'text-yellow-400';
    return 'text-rose-400';
  };

  const getScoreGradient = (score: number) => {
      if (score >= 80) return 'from-emerald-500/20 to-teal-500/5 border-emerald-500/30';
      if (score >= 50) return 'from-yellow-500/20 to-orange-500/5 border-yellow-500/30';
      return 'from-rose-500/20 to-red-500/5 border-rose-500/30';
  };

  // SVG Config
  const radius = 40;
  const stroke = 8;
  const normalizedRadius = radius - stroke / 2;
  const circumference = normalizedRadius * 2 * Math.PI;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      />

      <div className="
        relative w-full max-w-lg
        bg-slate-900/90 backdrop-blur-2xl
        border border-white/10
        rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.6)]
        overflow-hidden flex flex-col max-h-[85vh]
        animate-[fadeIn_0.3s_ease-out]
      ">
        
        {isLoading ? (
            <div className="flex flex-col items-center justify-center p-12 space-y-4">
                <div className="relative">
                    <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Zap size={24} className="text-primary animate-pulse" />
                    </div>
                </div>
                <p className="text-slate-300 font-medium animate-pulse">Analyzing spending patterns...</p>
            </div>
        ) : advice ? (
            <>
                {/* Header */}
                <div className="p-6 pb-0 flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <ShieldCheck className="text-primary" />
                            Financial Health Report
                        </h2>
                        <p className="text-sm text-slate-400 mt-1">AI-powered analysis of your history</p>
                    </div>
                    <button 
                        onClick={onClose} 
                        className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white"
                    >
                        <X size={24} />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
                    
                    {/* Score Card */}
                    <div className={`p-5 rounded-2xl border bg-gradient-to-br ${getScoreGradient(advice.healthScore)} flex items-center gap-5`}>
                        <div className="relative flex items-center justify-center w-20 h-20 shrink-0">
                            {/* Rotated SVG container */}
                            <svg 
                                height="100%" 
                                width="100%" 
                                viewBox="0 0 100 100" 
                                className="transform -rotate-90 drop-shadow-lg"
                            >
                                <circle
                                    stroke="currentColor"
                                    strokeWidth={stroke}
                                    fill="transparent"
                                    r={normalizedRadius}
                                    cx="50"
                                    cy="50"
                                    className="text-black/30"
                                />
                                <circle
                                    stroke="currentColor"
                                    strokeWidth={stroke}
                                    strokeLinecap="round"
                                    fill="transparent"
                                    r={normalizedRadius}
                                    cx="50"
                                    cy="50"
                                    style={{
                                        strokeDasharray: `${circumference} ${circumference}`,
                                        strokeDashoffset: circumference - (advice.healthScore / 100) * circumference,
                                        transition: 'stroke-dashoffset 1.5s ease-out'
                                    }}
                                    className={getScoreColor(advice.healthScore)}
                                />
                            </svg>
                            <span className={`absolute text-2xl font-bold ${getScoreColor(advice.healthScore)}`}>
                                {advice.healthScore}
                            </span>
                        </div>
                        <div className="flex-1">
                            <h3 className="text-slate-100 font-bold text-lg mb-1">Overall Score</h3>
                            <p className="text-sm text-slate-300 leading-snug">{advice.summary}</p>
                        </div>
                    </div>

                    {/* Critical Insights */}
                    {advice.warnings.length > 0 && (
                        <div className="space-y-3">
                            <h3 className="text-rose-400 font-bold text-sm uppercase tracking-wider flex items-center gap-2">
                                <AlertTriangle size={16} /> Critical Alerts
                            </h3>
                            {advice.warnings.map((warn, i) => (
                                <div key={i} className="bg-rose-500/10 border border-rose-500/20 p-3 rounded-xl text-rose-100 text-sm flex gap-3 items-start">
                                    <span className="mt-0.5">•</span>
                                    <span>{warn}</span>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Actionable Tips */}
                    <div className="space-y-3">
                        <h3 className="text-emerald-400 font-bold text-sm uppercase tracking-wider flex items-center gap-2">
                            <Lightbulb size={16} /> Actionable Tips
                        </h3>
                        {advice.tips.map((tip, i) => (
                            <div key={i} className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl text-emerald-100 text-sm flex gap-3 items-start">
                                <span className="mt-0.5">💡</span>
                                <span>{tip}</span>
                            </div>
                        ))}
                    </div>

                </div>
            </>
        ) : (
             <div className="p-8 text-center text-slate-400">
                Failed to generate report. Please try again.
             </div>
        )}
      </div>
    </div>
  );
};

export default AdvisorModal;