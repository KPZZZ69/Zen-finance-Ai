import React, { useState } from 'react';
import { X, Check, Wallet } from 'lucide-react';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBudget: number;
  onSave: (amount: number) => void;
}

const BudgetModal: React.FC<BudgetModalProps> = ({ isOpen, onClose, currentBudget, onSave }) => {
  const [amount, setAmount] = useState(currentBudget.toString());

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!isNaN(val) && val >= 0) {
      onSave(val);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      />

      <div className="
        relative w-full max-w-sm
        bg-slate-900/90 backdrop-blur-2xl
        border border-white/10
        rounded-3xl shadow-2xl
        p-6
        animate-[fadeIn_0.2s_ease-out]
      ">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Wallet className="text-emerald-400" />
            Monthly Budget
          </h2>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">
              Set Limit (₹)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold">₹</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-black/20 border border-white/10 rounded-2xl py-4 pl-10 pr-4 text-2xl font-bold text-white focus:outline-none focus:border-emerald-500/50 transition-colors"
                placeholder="0"
                autoFocus
              />
            </div>
            <p className="text-xs text-slate-500 mt-3">
              We'll alert you if your expenses get close to this limit. Set to 0 to disable.
            </p>
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3.5 rounded-2xl shadow-lg shadow-emerald-500/20 transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Check size={20} />
            Save Budget
          </button>
        </form>
      </div>
    </div>
  );
};

export default BudgetModal;