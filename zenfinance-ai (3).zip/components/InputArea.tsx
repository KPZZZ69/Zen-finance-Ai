import React, { useState } from 'react';
import { Send, Loader2, Sparkles } from 'lucide-react';

interface InputAreaProps {
  onSend: (text: string) => void;
  isLoading: boolean;
}

const InputArea: React.FC<InputAreaProps> = ({ onSend, isLoading }) => {
  const [text, setText] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isLoading) {
      onSend(text);
      setText('');
    }
  };

  return (
    // pb-[max(...)] ensures content isn't hidden behind the Android gesture bar
    <div className="fixed bottom-0 left-0 right-0 p-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] z-50 transition-all duration-300">
      {/* Gradient fade at bottom for smooth blending */}
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-background via-background/90 to-transparent -z-10 pointer-events-none" />
      
      <div className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit} className="relative flex items-center group" autoComplete="off">
          
          {/* Input Glow Container */}
          <div className={`
            absolute -inset-0.5 rounded-3xl bg-gradient-to-r from-primary to-secondary opacity-0 blur transition duration-500
            ${isFocused ? 'opacity-30' : 'group-hover:opacity-20'}
          `} />
          
          <div className="relative w-full flex items-center">
            <div className={`
              absolute left-4 transition-colors duration-300
              ${isFocused ? 'text-primary' : 'text-slate-500'}
            `}>
              <Sparkles size={20} className={isLoading ? "animate-pulse" : ""} />
            </div>
            
            <input
              type="text"
              inputMode="text"
              enterKeyHint="send"
              value={text}
              onChange={(e) => setText(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="Type '150 coffee'..."
              className="
                w-full 
                bg-slate-900/80 backdrop-blur-2xl 
                border border-white/10 
                text-slate-100 
                rounded-3xl 
                py-4 pl-12 pr-14 
                focus:outline-none 
                placeholder:text-slate-600
                shadow-[0_8px_32px_rgba(0,0,0,0.2)]
                transition-all duration-300
                text-base
              "
              disabled={isLoading}
            />
            
            <button
              type="submit"
              disabled={isLoading || !text.trim()}
              className={`
                absolute right-2 p-2.5 rounded-2xl text-white shadow-lg
                transition-all duration-300 active:scale-90
                ${text.trim() && !isLoading 
                  ? 'bg-gradient-to-br from-primary to-blue-600 shadow-blue-500/30' 
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'}
              `}
            >
              {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
            </button>
          </div>
        </form>
        
        {/* Hide footer on focus for more space on Android */}
        <div className={`
          overflow-hidden transition-all duration-500 ease-in-out
          ${isFocused ? 'max-h-0 opacity-0 mt-0' : 'max-h-10 opacity-100 mt-4'}
        `}>
          <p className={`
            text-center text-[10px] uppercase tracking-[0.2em] font-semibold
            ${isFocused ? 'text-primary/70' : 'text-slate-600'}
          `}>
            Zen AI • Developed By Prathamesh Kale
          </p>
        </div>
      </div>
    </div>
  );
};

export default InputArea;