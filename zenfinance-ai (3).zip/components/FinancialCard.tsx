import React from 'react';

interface FinancialCardProps {
  label: string;
  amount: number;
  type: 'balance' | 'income' | 'expense';
}

const FinancialCard: React.FC<FinancialCardProps> = ({ label, amount, type }) => {
  const getStyles = () => {
    switch (type) {
      case 'income':
        return 'from-emerald-500/10 to-teal-500/5 border-emerald-500/20 text-emerald-100 group-hover:border-emerald-500/30';
      case 'expense':
        return 'from-rose-500/10 to-pink-500/5 border-rose-500/20 text-rose-100 group-hover:border-rose-500/30';
      default:
        return 'from-blue-500/10 to-indigo-500/5 border-blue-500/20 text-blue-100 group-hover:border-blue-500/30';
    }
  };

  const getGlowColor = () => {
      if (type === 'income') return 'rgba(16,185,129,0.2)';
      if (type === 'expense') return 'rgba(244,63,94,0.2)';
      return 'rgba(59,130,246,0.2)';
  };

  const getIcon = () => {
      if (type === 'balance') return '💰';
      if (type === 'income') return '📈';
      return '📉';
  }

  const styles = getStyles();
  const glowColor = getGlowColor();

  return (
    <div 
      className={`
        relative overflow-hidden
        flex flex-col p-5 rounded-3xl border flex-1 min-w-[130px]
        bg-gradient-to-br backdrop-blur-xl
        transition-all duration-300 ease-out
        group
        hover:scale-[1.02] active:scale-[0.98]
        ${styles}
      `}
      style={{
        '--card-glow': glowColor,
      } as React.CSSProperties}
    >
      {/* Dynamic Breathing Background */}
      <div 
        className="absolute -inset-full opacity-20 bg-gradient-to-tr from-transparent via-white/10 to-transparent rotate-45 animate-breathe pointer-events-none"
      />
      
      {/* Interactive Hover Glow */}
      <div 
        className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100 pointer-events-none"
        style={{
            boxShadow: `inset 0 0 50px var(--card-glow), 0 0 20px var(--card-glow)`
        }}
      />

      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity text-4xl grayscale group-hover:grayscale-0 animate-float-delayed">
        {getIcon()}
      </div>
      
      <span className="relative z-10 text-[10px] font-bold opacity-70 uppercase tracking-widest mb-2">
        {label}
      </span>
      
      <span className="relative z-10 text-2xl md:text-3xl font-bold tracking-tight drop-shadow-md">
        <span className="opacity-50 mr-1 text-lg font-normal">₹</span>
        {Math.abs(amount).toLocaleString('en-IN')}
      </span>
      
      {/* Subtle internal shine for glass effect */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/5 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
    </div>
  );
};

export default FinancialCard;