import React from 'react';
import { X, Trash2, Calendar, Repeat } from 'lucide-react';
import { RecurringTransaction } from '../types';
import { stringToColor } from '../utils/helpers';

interface RecurringManagerProps {
  isOpen: boolean;
  onClose: () => void;
  recurringTransactions: RecurringTransaction[];
  onDelete: (id: string) => void;
}

const RecurringManager: React.FC<RecurringManagerProps> = ({
  isOpen,
  onClose,
  recurringTransactions,
  onDelete,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      />

      <div className="
        relative w-full max-w-md 
        bg-slate-900/80 backdrop-blur-2xl
        border border-white/10
        rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.5)]
        overflow-hidden flex flex-col max-h-[80vh]
        animate-[fadeIn_0.2s_ease-out]
      ">
        <div className="p-5 border-b border-white/5 flex justify-between items-center bg-white/5">
          <h3 className="text-lg font-bold text-white tracking-wide flex items-center gap-2">
            <Repeat size={20} className="text-primary" />
            Recurring Subscriptions
          </h3>
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
          {recurringTransactions.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <p>No recurring transactions found.</p>
              <p className="text-xs mt-2">Try typing "Netflix 200 monthly"</p>
            </div>
          ) : (
            recurringTransactions.map((rt) => (
              <div 
                key={rt.id} 
                className="group flex items-center justify-between p-4 rounded-2xl border border-white/5 bg-white/5 hover:bg-white/10 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div 
                    className="w-10 h-10 flex items-center justify-center rounded-xl bg-black/20 text-xl border border-white/5"
                  >
                    {rt.template.emoji}
                  </div>
                  <div>
                    <h4 className="text-slate-200 font-bold text-sm tracking-wide">
                      {rt.template.description || rt.template.category}
                    </h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] uppercase font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                        {rt.frequency}
                      </span>
                      <span className="text-xs text-slate-400 flex items-center gap-1">
                        <Calendar size={10} />
                        Next: {new Date(rt.nextDueDate).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`font-bold text-sm ${rt.template.type === 'income' ? 'text-income' : 'text-slate-200'}`}>
                     ₹{rt.template.amount}
                  </span>
                  <button 
                    onClick={() => onDelete(rt.id)}
                    className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
                    title="Stop Recurring"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="p-4 border-t border-white/5 bg-white/5 text-center text-xs text-slate-500">
          Auto-renews at midnight on due date
        </div>
      </div>
    </div>
  );
};

export default RecurringManager;