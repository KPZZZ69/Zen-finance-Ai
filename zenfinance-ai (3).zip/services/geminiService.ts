import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AppState, FinancialAdvice, AIBatchResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const modelId = "gemini-3-flash-preview";

export const processTransaction = async (
  input: string,
  currentState: AppState
): Promise<AIBatchResponse> => {
  
  const categories = currentState.categories;
  
  // Get last 10 transactions for context
  const recentHistory = currentState.transactions
    .slice(0, 10)
    .map(t => `${t.date.split('T')[0]}: ${t.type} ${t.amount} (${t.category}) - ${t.description}`)
    .join('\n');

  const responseSchema: Schema = {
    type: Type.OBJECT,
    properties: {
      transactions: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            type: {
              type: Type.STRING,
              enum: ["income", "expense"],
              description: "The type of the transaction.",
            },
            amount: {
              type: Type.NUMBER,
              description: "The numerical amount of the transaction.",
            },
            category: {
              type: Type.STRING,
              enum: categories,
              description: `The category of the transaction. Must be one of: ${categories.join(', ')}`,
            },
            emoji: {
              type: Type.STRING,
              description: "A single emoji that best represents this specific transaction (e.g. 🍕 for pizza, 🚌 for bus).",
            },
            recurrence: {
              type: Type.STRING,
              enum: ["none", "daily", "weekly", "monthly", "yearly"],
              description: "The frequency if the user implies this is a repeating payment (e.g., 'monthly rent', 'weekly pocket money'). Default is 'none'.",
            },
            description: {
              type: Type.STRING,
              description: "A short label for the transaction inferred from input (e.g. 'Pizza', 'Salary').",
            },
          },
          required: ["type", "amount", "category", "emoji", "recurrence", "description"]
        }
      },
      insight: {
        type: Type.STRING,
        description: "A short, critical, and context-aware insight about this batch of transactions. If it's multiple items, summarize the impact.",
      }
    },
    required: [
      "transactions",
      "insight",
    ],
  };

  const budgetInfo = currentState.monthlyBudget > 0 
    ? `Monthly Budget: ${currentState.monthlyBudget}.` 
    : "No Budget Set.";

  const prompt = `
    You are an intelligent financial assistant.
    
    Current Financial State:
    - Balance: ${currentState.currentBalance}
    - ${budgetInfo}
    
    Recent Transactions (for context):
    ${recentHistory || "No recent transactions."}
    
    User Input: "${input}"
    
    Task:
    1. Parse the input which may contain ONE or MULTIPLE transactions (e.g. "+2000 salary -200 food").
    2. Break it down into individual transaction items.
    3. Categorize strictly into: ${categories.join(', ')}.
    4. Generate a single INSIGHT for this update.
    
    Rules:
    - Default to Expense unless '+' or income keywords used.
    - JSON only.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as AIBatchResponse;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const generateFinancialAdvice = async (currentState: AppState): Promise<FinancialAdvice> => {
    // 1. Prepare data summary
    const totalTx = currentState.transactions.length;
    if (totalTx === 0) {
        return {
            healthScore: 100,
            summary: "Start adding transactions to get personalized advice!",
            warnings: [],
            tips: ["Try tracking your first expense below."]
        };
    }

    const history = currentState.transactions.slice(0, 30).map(t => 
        `${t.date.split('T')[0]}: ${t.type.toUpperCase()} ${t.amount} (${t.category})`
    ).join('\n');

    const budgetInfo = currentState.monthlyBudget > 0 
      ? `Budget: ${currentState.monthlyBudget}. Utilization: ${Math.round((currentState.totalExpense / currentState.monthlyBudget) * 100)}%` 
      : "No Budget Set";

    // 2. Define Schema
    const adviceSchema: Schema = {
        type: Type.OBJECT,
        properties: {
            healthScore: { type: Type.NUMBER, description: "A score from 0-100 representing financial health based on savings rate, budget adherence, and spending habits." },
            summary: { type: Type.STRING, description: "A 2-3 sentence overview of their financial behavior." },
            warnings: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Critical alerts about overspending, budget breaches, or bad habits." 
            },
            tips: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Actionable, specific advice to save money or improve health." 
            }
        },
        required: ["healthScore", "summary", "warnings", "tips"]
    };

    // 3. Prompt
    const prompt = `
        Analyze this user's financial data deeply.
        
        Overview:
        - Income: ${currentState.totalIncome}
        - Expense: ${currentState.totalExpense}
        - Balance: ${currentState.currentBalance}
        - ${budgetInfo}
        
        Recent Transaction History (Last 30):
        ${history}
        
        Provide a "Financial Health Check".
        1. Calculate a health score (0-100). If they are over budget, score should be low.
        2. Identify specific "leaks".
        3. Give harsh but helpful warnings if necessary.
        4. Give very specific tips.
    `;

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: adviceSchema,
            },
        });

        const text = response.text;
        if (!text) throw new Error("No advice generated");
        return JSON.parse(text);
    } catch (error) {
        console.error("Advice Error:", error);
        throw error;
    }
};