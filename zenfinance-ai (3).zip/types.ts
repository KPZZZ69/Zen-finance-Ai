export type TransactionType = 'income' | 'expense';

export const DEFAULT_CATEGORIES = [
  'Food',
  'Travel',
  'Mobile / Internet',
  'Entertainment',
  'Shopping',
  'Miscellaneous',
  'Savings',
];

export type Category = string;
export type RecurrenceFrequency = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';

// The structure received from Gemini for a single item in a batch
export interface AIParsedItem {
  type: TransactionType;
  amount: number;
  category: Category;
  description: string;
  emoji: string;
  recurrence: RecurrenceFrequency;
}

// The overall structure received from Gemini
export interface AIBatchResponse {
  transactions: AIParsedItem[];
  insight: string;
}

// Legacy interface (kept for compatibility if needed, though mostly superseded by batch logic)
export interface AIResponse {
  type: TransactionType;
  amount: number;
  category: Category;
  description?: string;
  emoji: string;
  recurrence: RecurrenceFrequency;
  total_income: number;
  total_expense: number;
  current_balance: number;
  insight: string;
}

// The structure stored in our app history
export interface Transaction {
  id: string;
  date: string; // ISO string
  originalInput: string;
  type: TransactionType;
  amount: number;
  category: Category;
  description?: string;
  emoji: string;
  recurrence: RecurrenceFrequency;
  total_income: number;
  total_expense: number;
  current_balance: number;
  insight: string;
  fromRecurringId?: string; 
}

export interface RecurringTransaction {
  id: string;
  frequency: RecurrenceFrequency;
  nextDueDate: string; // ISO string
  template: Omit<Transaction, 'id' | 'date' | 'originalInput' | 'fromRecurringId'>;
  originalInput: string;
  active: boolean;
}

export interface FinancialAdvice {
  healthScore: number;
  summary: string;
  warnings: string[];
  tips: string[];
}

export interface AppState {
  totalIncome: number;
  totalExpense: number;
  currentBalance: number;
  monthlyBudget: number; // Added budget field
  transactions: Transaction[];
  recurringTransactions: RecurringTransaction[];
  categories: string[];
  categoryColors: Record<string, string>;
  categoryEmojis: Record<string, string>;
}