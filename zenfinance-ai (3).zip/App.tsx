import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { TrendingUp, AlertCircle, History, Settings, Repeat, Sparkles, Wallet, Edit3, Save } from 'lucide-react';
import { processTransaction, generateFinancialAdvice } from './services/geminiService';
import { AppState, Transaction, RecurringTransaction, DEFAULT_CATEGORIES, FinancialAdvice, AIBatchResponse } from './types';
import FinancialCard from './components/FinancialCard';
import TransactionItem from './components/TransactionItem';
import InputArea from './components/InputArea';
import Charts from './components/Charts';
import CategoryManager from './components/CategoryManager';
import RecurringManager from './components/RecurringManager';
import AdvisorModal from './components/AdvisorModal';
import BudgetModal from './components/BudgetModal';
import DataModal from './components/DataModal';
import IntroSequence from './components/IntroSequence';
import { stringToColor, getColorForCategory, DEFAULT_CATEGORY_EMOJIS, getEmojiForCategory } from './utils/helpers';

// Initialize default colors and emojis
const INITIAL_COLORS: Record<string, string> = {};
const INITIAL_EMOJIS: Record<string, string> = { ...DEFAULT_CATEGORY_EMOJIS };

DEFAULT_CATEGORIES.forEach(cat => {
  INITIAL_COLORS[cat] = stringToColor(cat);
  if (!INITIAL_EMOJIS[cat]) INITIAL_EMOJIS[cat] = '🏷️';
});

const INITIAL_STATE: AppState = {
  totalIncome: 0,
  totalExpense: 0,
  currentBalance: 0,
  monthlyBudget: 0, // Default 0 means no budget
  transactions: [],
  recurringTransactions: [],
  categories: DEFAULT_CATEGORIES,
  categoryColors: INITIAL_COLORS,
  categoryEmojis: INITIAL_EMOJIS,
};

const STORAGE_KEY = 'zenfinance_state_v4';
const INTRO_SEEN_KEY = 'zenfinance_intro_seen';

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [introType, setIntroType] = useState<'cinematic' | 'micro'>('cinematic');

  const [state, setState] = useState<AppState>(INITIAL_STATE);
  const [isLoading, setIsLoading] = useState(false);
  const [lastInsight, setLastInsight] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Modal States
  const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);
  const [isRecurringManagerOpen, setIsRecurringManagerOpen] = useState(false);
  const [isAdvisorOpen, setIsAdvisorOpen] = useState(false);
  const [isBudgetOpen, setIsBudgetOpen] = useState(false);
  const [isDataModalOpen, setIsDataModalOpen] = useState(false);
  
  // Advisor Data
  const [isAdviceLoading, setIsAdviceLoading] = useState(false);
  const [financialAdvice, setFinancialAdvice] = useState<FinancialAdvice | null>(null);

  // Check Intro Status
  useEffect(() => {
    const hasSeenIntro = localStorage.getItem(INTRO_SEEN_KEY);
    if (hasSeenIntro) {
      setIntroType('micro');
    } else {
      setIntroType('cinematic');
    }
  }, []);

  const handleIntroComplete = () => {
    localStorage.setItem(INTRO_SEEN_KEY, 'true');
    setShowIntro(false);
  };

  // Load from LocalStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        
        // Merge with initial state to ensure structure integrity for new features
        const mergedState = { ...INITIAL_STATE, ...parsed };

        // Ensure critical arrays exist
        if (!mergedState.categories || !Array.isArray(mergedState.categories)) {
          mergedState.categories = DEFAULT_CATEGORIES;
        }
        if (!mergedState.recurringTransactions) {
          mergedState.recurringTransactions = [];
        }
        if (!mergedState.transactions) {
            mergedState.transactions = [];
        }

        // Migration: Ensure categoryColors exists
        if (!mergedState.categoryColors || Object.keys(mergedState.categoryColors).length === 0) {
            mergedState.categoryColors = {};
            mergedState.categories.forEach((cat: string) => {
                mergedState.categoryColors[cat] = stringToColor(cat);
            });
        }
        // Migration: Ensure categoryEmojis exists
        if (!mergedState.categoryEmojis || Object.keys(mergedState.categoryEmojis).length === 0) {
            mergedState.categoryEmojis = {};
            mergedState.categories.forEach((cat: string) => {
                mergedState.categoryEmojis[cat] = getEmojiForCategory(cat);
            });
        }
        setState(mergedState);
      } catch (e) {
        console.error("Failed to parse saved state", e);
      }
    }
  }, []);

  // Save to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // Check for due recurring transactions on mount and when state changes
  useEffect(() => {
    checkRecurringTransactions();
  }, [state.recurringTransactions]);

  const checkRecurringTransactions = () => {
    const now = new Date();
    let newState = { ...state };
    let modified = false;
    let newTransactionsAdded: Transaction[] = [];

    const updatedRecurring = newState.recurringTransactions.map(rt => {
      let nextDate = new Date(rt.nextDueDate);
      let updatedRt = { ...rt };
      
      // If due date is passed
      while (nextDate <= now) {
        modified = true;
        
        // Create the new transaction
        const newTx: Transaction = {
          id: uuidv4(),
          date: nextDate.toISOString(), // Use the scheduled date, not "now"
          originalInput: `${rt.originalInput} (Auto)`,
          type: rt.template.type,
          amount: rt.template.amount,
          category: rt.template.category,
          description: rt.template.description,
          emoji: rt.template.emoji,
          recurrence: rt.frequency,
          total_income: 0, // Will calc later
          total_expense: 0, // Will calc later
          current_balance: 0, // Will calc later
          insight: "Recurring payment processed.",
          fromRecurringId: rt.id
        };

        newTransactionsAdded.push(newTx);

        // Update totals
        if (newTx.type === 'income') {
          newState.totalIncome += newTx.amount;
          newState.currentBalance += newTx.amount;
        } else {
          newState.totalExpense += newTx.amount;
          newState.currentBalance -= newTx.amount;
        }
        
        // Calculate NEXT due date
        if (rt.frequency === 'daily') nextDate.setDate(nextDate.getDate() + 1);
        if (rt.frequency === 'weekly') nextDate.setDate(nextDate.getDate() + 7);
        if (rt.frequency === 'monthly') nextDate.setMonth(nextDate.getMonth() + 1);
        if (rt.frequency === 'yearly') nextDate.setFullYear(nextDate.getFullYear() + 1);
      }
      
      updatedRt.nextDueDate = nextDate.toISOString();
      return updatedRt;
    });

    if (modified) {
      // Sort new transactions into the list
      const allTransactions = [...newTransactionsAdded, ...newState.transactions].sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );

      setState(prev => ({
        ...prev,
        totalIncome: newState.totalIncome,
        totalExpense: newState.totalExpense,
        currentBalance: newState.currentBalance,
        transactions: allTransactions,
        recurringTransactions: updatedRecurring
      }));
    }
  };

  const handleTransaction = async (inputText: string) => {
    setIsLoading(true);
    setError(null);
    setLastInsight(null);

    try {
      // Expecting a batch response now
      const aiResponse: AIBatchResponse = await processTransaction(inputText, state);

      let runningIncome = state.totalIncome;
      let runningExpense = state.totalExpense;
      let runningBalance = state.currentBalance;
      
      const newTransactions: Transaction[] = [];
      const newRecurringTransactions: RecurringTransaction[] = [...state.recurringTransactions];
      
      let updatedCategoryColors = { ...state.categoryColors };
      let updatedCategoryEmojis = { ...state.categoryEmojis };

      // Process each transaction returned by AI
      for (const item of aiResponse.transactions) {
          // Calculate new totals for this specific transaction
          if (item.type === 'income') {
              runningIncome += item.amount;
              runningBalance += item.amount;
          } else {
              runningExpense += item.amount;
              runningBalance -= item.amount;
          }

          // Ensure color/emoji
          if (!updatedCategoryColors[item.category]) {
              updatedCategoryColors[item.category] = stringToColor(item.category);
              updatedCategoryEmojis[item.category] = '✨';
          }

          const newTransaction: Transaction = {
            id: uuidv4(),
            date: new Date().toISOString(),
            originalInput: inputText, // They all share the same input text
            type: item.type,
            amount: item.amount,
            category: item.category,
            description: item.description,
            emoji: item.emoji,
            recurrence: item.recurrence,
            total_income: runningIncome,
            total_expense: runningExpense,
            current_balance: runningBalance,
            insight: aiResponse.insight // Share the batch insight
          };

          newTransactions.push(newTransaction);

          // Handle Recurrence Creation
          if (item.recurrence && item.recurrence !== 'none') {
            const nextDate = new Date();
            // Calculate first NEXT due date
            if (item.recurrence === 'daily') nextDate.setDate(nextDate.getDate() + 1);
            if (item.recurrence === 'weekly') nextDate.setDate(nextDate.getDate() + 7);
            if (item.recurrence === 'monthly') nextDate.setMonth(nextDate.getMonth() + 1);
            if (item.recurrence === 'yearly') nextDate.setFullYear(nextDate.getFullYear() + 1);

            const newRecurring: RecurringTransaction = {
              id: uuidv4(),
              frequency: item.recurrence,
              nextDueDate: nextDate.toISOString(),
              originalInput: inputText,
              active: true,
              template: {
                 type: item.type,
                 amount: item.amount,
                 category: item.category,
                 description: item.description,
                 emoji: item.emoji,
                 recurrence: item.recurrence,
                 total_income: 0,
                 total_expense: 0,
                 current_balance: 0,
                 insight: ''
              }
            };
            newRecurringTransactions.push(newRecurring);
          }
      }

      setState(prev => ({
        ...prev,
        totalIncome: runningIncome,
        totalExpense: runningExpense,
        currentBalance: runningBalance,
        transactions: [...newTransactions.reverse(), ...prev.transactions], // Add new ones at top (reverse because we processed them in order, but want newest first)
        recurringTransactions: newRecurringTransactions,
        categoryColors: updatedCategoryColors,
        categoryEmojis: updatedCategoryEmojis,
      }));

      setLastInsight(aiResponse.insight);

    } catch (err) {
      console.error(err);
      setError("Failed to process transaction. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGetAdvice = async () => {
    setIsAdvisorOpen(true);
    setIsAdviceLoading(true);
    setFinancialAdvice(null);
    try {
        const advice = await generateFinancialAdvice(state);
        setFinancialAdvice(advice);
    } catch (e) {
        // Error handling mostly visual in modal
    } finally {
        setIsAdviceLoading(false);
    }
  };

  const handleReset = () => {
    if (confirm("Are you sure you want to clear all data?")) {
      setState(INITIAL_STATE);
      setLastInsight(null);
      localStorage.removeItem(INTRO_SEEN_KEY); // Reset intro flag too for demo purposes if reset
    }
  };

  const handleImportData = (importedState: AppState) => {
      // Ensure merged state is robust
      const merged = { ...INITIAL_STATE, ...importedState };
      setState(merged);
  };

  const handleAddCategory = (name: string, color: string, emoji: string) => {
    if (!state.categories.includes(name)) {
      setState(prev => ({
        ...prev,
        categories: [...prev.categories, name],
        categoryColors: {
            ...prev.categoryColors,
            [name]: color
        },
        categoryEmojis: {
            ...prev.categoryEmojis,
            [name]: emoji
        }
      }));
    }
  };

  const handleEditCategory = (oldName: string, newName: string, newColor: string, newEmoji: string) => {
    // If name didn't change but props did
    if (oldName === newName) {
        setState(prev => ({
            ...prev,
            categoryColors: {
                ...prev.categoryColors,
                [oldName]: newColor
            },
            categoryEmojis: {
                ...prev.categoryEmojis,
                [oldName]: newEmoji
            }
        }));
        return;
    }

    if (state.categories.includes(newName)) return; // Prevent duplicate names

    setState(prev => {
        const newColors = { ...prev.categoryColors };
        const newEmojis = { ...prev.categoryEmojis };
        
        delete newColors[oldName];
        delete newEmojis[oldName];
        
        newColors[newName] = newColor;
        newEmojis[newName] = newEmoji;

        return {
            ...prev,
            categories: prev.categories.map(c => c === oldName ? newName : c),
            categoryColors: newColors,
            categoryEmojis: newEmojis,
            transactions: prev.transactions.map(t => 
                t.category === oldName ? { ...t, category: newName } : t
            )
        };
    });
  };

  const handleDeleteCategory = (name: string) => {
    if (confirm(`Delete category "${name}"?`)) {
      setState(prev => {
          const newColors = { ...prev.categoryColors };
          const newEmojis = { ...prev.categoryEmojis };
          delete newColors[name];
          delete newEmojis[name];
          return {
            ...prev,
            categories: prev.categories.filter(c => c !== name),
            categoryColors: newColors,
            categoryEmojis: newEmojis,
          };
      });
    }
  };

  const handleDeleteRecurring = (id: string) => {
     if (confirm("Stop this recurring transaction? Past transactions will remain.")) {
       setState(prev => ({
         ...prev,
         recurringTransactions: prev.recurringTransactions.filter(rt => rt.id !== id)
       }));
     }
  };

  const handleBudgetSave = (amount: number) => {
    setState(prev => ({ ...prev, monthlyBudget: amount }));
  };

  // Budget Progress Calculation
  const budgetProgress = state.monthlyBudget > 0 ? (state.totalExpense / state.monthlyBudget) * 100 : 0;
  let budgetColor = 'bg-emerald-500';
  if (budgetProgress > 70) budgetColor = 'bg-orange-500';
  if (budgetProgress > 90) budgetColor = 'bg-rose-500';

  return (
    // Added select-none to prevent accidental text selection, making it feel like a native app
    <div className="min-h-screen bg-background text-slate-100 pb-44 font-sans selection:bg-cyan-500/30 selection:text-cyan-100 overflow-x-hidden relative select-none">
      
      {showIntro && <IntroSequence type={introType} onComplete={handleIntroComplete} />}

      {/* Living Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
          <div className="absolute top-[-10%] left-[-20%] w-[80vw] h-[80vw] bg-violet-600/10 rounded-full blur-[120px] mix-blend-screen animate-blob"></div>
          <div className="absolute top-[-20%] right-[-20%] w-[70vw] h-[70vw] bg-cyan-500/10 rounded-full blur-[100px] mix-blend-screen animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-[-20%] left-[20%] w-[90vw] h-[90vw] bg-blue-500/10 rounded-full blur-[120px] mix-blend-screen animate-blob animation-delay-4000"></div>
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }}></div>
      </div>

      {/* Header */}
      <header className="px-4 py-4 pt-8 md:px-6 md:py-6 md:pt-10 flex justify-between items-center max-w-2xl mx-auto sticky top-0 z-30">
        <div className="absolute inset-x-0 top-0 h-36 bg-gradient-to-b from-background via-background/95 to-transparent -z-10 pointer-events-none" />
        
        <div className="flex items-center gap-3 group cursor-default shrink-0">
          <div className="relative p-2.5 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl shadow-[0_0_25px_rgba(6,182,212,0.4)] group-hover:shadow-[0_0_40px_rgba(6,182,212,0.6)] transition-all duration-500 animate-float">
             <div className="absolute inset-0 bg-white/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity"></div>
             <TrendingUp size={22} className="text-white relative z-10 drop-shadow-md" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-blue-200 drop-shadow-[0_0_10px_rgba(255,255,255,0.1)] leading-none">
              ZenFinance
            </h1>
            <div className="mt-1">
                <p className="text-[9px] font-semibold text-slate-500 tracking-widest uppercase hidden sm:block">
                  by <span className="text-cyan-400 font-extrabold tracking-[0.15em] drop-shadow-[0_0_5px_rgba(34,211,238,0.6)]">Prathamesh Kale</span>
                </p>
            </div>
          </div>
        </div>
        
        <div className="flex gap-1.5 md:gap-2">
          {/* Data Management Button (Save Icon) */}
          <button
            onClick={() => setIsDataModalOpen(true)}
            className="p-2 md:p-2.5 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 hover:text-white rounded-xl transition-all border border-cyan-500/20 hover:border-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.1)] active:scale-95"
            title="Backup & Data"
          >
             <Save size={18} />
          </button>

          <button
            onClick={() => setIsBudgetOpen(true)}
            className="p-2 md:p-2.5 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 hover:text-white rounded-xl transition-all border border-emerald-500/20 hover:border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.1)] active:scale-95"
            title="Set Budget"
          >
             <Wallet size={18} />
          </button>

          <button
            onClick={handleGetAdvice}
            className="p-2 md:p-2.5 bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 hover:text-white rounded-xl transition-all border border-indigo-500/20 hover:border-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.1)] active:scale-95"
            title="Get AI Advice"
          >
             <Sparkles size={18} />
          </button>

          <button 
            onClick={() => setIsCategoryManagerOpen(true)}
            className="p-2 md:p-2.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-all border border-transparent hover:border-white/10"
            title="Manage Categories"
          >
            <Settings size={18} />
          </button>
          
          <button 
            onClick={handleReset}
            className="p-2 md:p-2.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-all border border-transparent hover:border-rose-500/20"
            title="Reset Data"
          >
            <History size={18} />
          </button>
        </div>
      </header>

      <main className="px-4 max-w-2xl mx-auto space-y-6 mt-0">
        
        {/* Dashboard Cards */}
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 px-6 -mx-6 snap-x">
          <FinancialCard label="Balance" amount={state.currentBalance} type="balance" />
          <FinancialCard label="Income" amount={state.totalIncome} type="income" />
          <FinancialCard label="Expenses" amount={state.totalExpense} type="expense" />
        </div>

        {/* Budget Progress Bar */}
        {state.monthlyBudget > 0 && (
          <div 
            className="relative bg-slate-900/60 backdrop-blur-md border border-white/5 rounded-2xl p-4 cursor-pointer group hover:bg-slate-900/80 transition-colors"
            onClick={() => setIsBudgetOpen(true)}
          >
            <div className="flex justify-between items-end mb-2">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Monthly Budget</span>
                <div className="text-white font-bold text-lg mt-0.5">
                  ₹{state.totalExpense.toLocaleString('en-IN')} <span className="text-slate-500 text-sm font-normal">/ ₹{state.monthlyBudget.toLocaleString('en-IN')}</span>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-sm font-bold ${budgetProgress > 100 ? 'text-rose-500' : 'text-emerald-400'}`}>
                   {Math.round(budgetProgress)}% Used
                </div>
              </div>
            </div>
            {/* Progress Track */}
            <div className="h-3 w-full bg-black/40 rounded-full overflow-hidden border border-white/5">
              {/* Progress Fill */}
              <div 
                className={`h-full ${budgetColor} transition-all duration-1000 ease-out relative`}
                style={{ width: `${Math.min(budgetProgress, 100)}%` }}
              >
                 <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>
            <Edit3 size={14} className="absolute top-4 right-4 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        )}

        {/* AI Insight Banner */}
        {lastInsight && (
          <div className="relative overflow-hidden group animate-[fadeIn_0.5s_ease-out]">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 via-purple-500/20 to-indigo-500/20 blur-xl opacity-50 group-hover:opacity-70 transition-opacity" />
            <div className="relative bg-slate-900/40 backdrop-blur-xl border border-indigo-500/30 p-5 rounded-3xl flex gap-4 items-start shadow-[0_8px_32px_rgba(99,102,241,0.1)] group-hover:shadow-[0_8px_40px_rgba(99,102,241,0.2)] transition-shadow">
              <div className="p-2.5 bg-indigo-500/20 rounded-2xl shrink-0 shadow-[0_0_15px_rgba(99,102,241,0.3)] border border-indigo-500/20 group-hover:scale-110 transition-transform duration-300">
                 <TrendingUp size={20} className="text-indigo-300" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  AI Insight <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
                </p>
                <p className="text-sm text-slate-200 leading-relaxed font-medium">{lastInsight}</p>
              </div>
            </div>
          </div>
        )}

        {/* Error Banner */}
        {error && (
          <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-2xl flex gap-3 items-center text-rose-200 animate-pulse backdrop-blur-sm shadow-[0_0_20px_rgba(244,63,94,0.2)]">
            <AlertCircle size={20} />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}

        {/* Analytics Section - Removed border-white/5 for cleaner look */}
        {state.transactions.length > 0 && (
          <section className="bg-slate-900/40 backdrop-blur-xl rounded-[2.5rem] p-6 shadow-2xl relative overflow-hidden transition-colors">
             {/* Decorative glow */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-[80px] -z-10 animate-pulse-slow" />
             
             <h2 className="text-lg font-bold mb-6 text-slate-200 flex items-center gap-2">
                <span className="w-1.5 h-6 bg-gradient-to-b from-cyan-400 to-blue-500 rounded-full shadow-[0_0_10px_rgba(6,182,212,0.5)]"></span>
                Spending Breakdown
             </h2>
             <Charts 
                transactions={state.transactions} 
                categoryColors={state.categoryColors}
                categoryEmojis={state.categoryEmojis} 
             />
          </section>
        )}

        {/* Recent Transactions Feed */}
        <section>
          <div className="flex items-center gap-2 mb-5 px-1">
             <h2 className="text-lg font-bold text-slate-200 flex items-center gap-2">
                <span className="w-1.5 h-6 bg-gradient-to-b from-emerald-400 to-teal-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]"></span>
                Recent Activity
             </h2>
          </div>
          
          <div className="space-y-3 min-h-[200px] pb-8">
            {state.transactions.length === 0 ? (
              <div className="relative flex flex-col items-center justify-center py-20 bg-white/5 backdrop-blur-sm rounded-[2.5rem] border border-dashed border-white/10 overflow-hidden group hover:bg-white/10 transition-colors">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-blue-500/20 rounded-full blur-[60px] animate-pulse"></div>
                <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-purple-500/10 rounded-full blur-[40px] animate-blob"></div>
                
                <div className="relative z-10 flex flex-col items-center">
                    <div className="text-5xl mb-4 opacity-70 grayscale-0 drop-shadow-[0_0_15px_rgba(255,255,255,0.2)] animate-float">💸</div>
                    <p className="font-bold text-lg text-slate-200 tracking-wide">No transactions yet</p>
                    <p className="text-sm mt-1 text-slate-400">Try typing "250 pizza" below</p>
                </div>
              </div>
            ) : (
              state.transactions.map((t) => (
                <TransactionItem 
                  key={t.id} 
                  transaction={t} 
                  categoryColor={getColorForCategory(t.category, state.categoryColors)}
                />
              ))
            )}
          </div>
        </section>

      </main>

      <InputArea onSend={handleTransaction} isLoading={isLoading} />
      
      <CategoryManager 
        isOpen={isCategoryManagerOpen}
        onClose={() => setIsCategoryManagerOpen(false)}
        categories={state.categories}
        categoryColors={state.categoryColors}
        categoryEmojis={state.categoryEmojis}
        onAdd={handleAddCategory}
        onEdit={handleEditCategory}
        onDelete={handleDeleteCategory}
      />

      <RecurringManager 
        isOpen={isRecurringManagerOpen}
        onClose={() => setIsRecurringManagerOpen(false)}
        recurringTransactions={state.recurringTransactions}
        onDelete={handleDeleteRecurring}
      />

      <BudgetModal 
        isOpen={isBudgetOpen}
        onClose={() => setIsBudgetOpen(false)}
        currentBudget={state.monthlyBudget}
        onSave={handleBudgetSave}
      />

      <DataModal 
        isOpen={isDataModalOpen}
        onClose={() => setIsDataModalOpen(false)}
        state={state}
        onImport={handleImportData}
      />

      <AdvisorModal
        isOpen={isAdvisorOpen}
        onClose={() => setIsAdvisorOpen(false)}
        advice={financialAdvice}
        isLoading={isAdviceLoading}
      />
    </div>
  );
}